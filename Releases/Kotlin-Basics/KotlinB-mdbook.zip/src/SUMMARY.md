# Summary

- [Getting Started](00.md)
- [Hello World Kotlin!](01-intro.md)
- [Data Types](02-types.md)
    - [Mutable & Immutable Variables](02-01-var.md)
    - [Strings](02-02-str.md)
    - [Math](02-03-math.md)
- [Conditional Expressions](03-conditionals.md)
    - [Conditional Operators](03-01-operators.md)
- [Collections](04-collections.md)
- [Loops](05-loops.md)
- [Functions](06-functions.md)
- [Classes](07-classes.md)
